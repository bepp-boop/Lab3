docker stop lbs-android
